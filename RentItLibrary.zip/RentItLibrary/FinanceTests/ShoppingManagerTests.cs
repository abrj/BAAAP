﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Finance;
using Persistence;
using UserManagement;

namespace FinanceTests
{
    [TestClass]
    public class ShoppingManagerTests
    {
        [TestMethod]
        public void TestAddPurchaseToCart()
        {
			ShoppingManager.AddPurchaseToShoppingCart(new LoginInfo(1206731771,DateTime.Now,LoginInfo.Role.User), 10);
			ShoppingManager.RemoveFromShoppingCart(new LoginInfo(1206731771, DateTime.Now, LoginInfo.Role.User), 10);
        }

		[TestMethod]
		public void TestAddPurchaseToCartTwice()
		{
			ShoppingManager.AddPurchaseToShoppingCart(new LoginInfo(1206731771, DateTime.Now, LoginInfo.Role.User), 10);
			ShoppingManager.AddPurchaseToShoppingCart(new LoginInfo(1206731771, DateTime.Now, LoginInfo.Role.User), 10);
			ShoppingManager.RemoveFromShoppingCart(new LoginInfo(1206731771, DateTime.Now, LoginInfo.Role.User), 10);
		}

		[TestMethod]
		public void TestAddRentToCart()
		{
			ShoppingManager.AddRentalToShoppingCart(new LoginInfo(1206731771, DateTime.Now, LoginInfo.Role.User), 10);
			ShoppingManager.RemoveFromShoppingCart(new LoginInfo(1206731771, DateTime.Now, LoginInfo.Role.User), 10);
		}

		[TestMethod]
		public void TestAddRentToCartTwice()
		{
			ShoppingManager.AddRentalToShoppingCart(new LoginInfo(1206731771, DateTime.Now, LoginInfo.Role.User), 10);
			ShoppingManager.AddRentalToShoppingCart(new LoginInfo(1206731771, DateTime.Now, LoginInfo.Role.User), 10);
			ShoppingManager.RemoveFromShoppingCart(new LoginInfo(1206731771, DateTime.Now, LoginInfo.Role.User), 10);
		}

		[TestMethod]
		public void TestRemoveFromCart()
		{
			ShoppingManager.AddRentalToShoppingCart(new LoginInfo(1206731771, DateTime.Now, LoginInfo.Role.User), 10);
			ShoppingManager.RemoveFromShoppingCart(new LoginInfo(1206731771, DateTime.Now, LoginInfo.Role.User), 10);
		}

		[TestMethod]
		public void TestRemoveFromCartItemNotInCart()
		{
			ShoppingManager.RemoveFromShoppingCart(new LoginInfo(1206731771, DateTime.Now, LoginInfo.Role.User), 10);
		}

		[TestMethod]
		public void TestClearCart()
		{
			ShoppingManager.ClearShoppingCart(new LoginInfo(1206731771, DateTime.Now, LoginInfo.Role.User));
		}


		[TestMethod]
		public void TestCheckOutEmptyCart()
		{
			ShoppingManager.CheckOut(new LoginInfo(1206731771, DateTime.Now, LoginInfo.Role.User));
		}


		[TestMethod]
		public void TestCheckOutOneItem()
		{
			var info = new LoginInfo(1206731771, DateTime.Now, LoginInfo.Role.User);
			ShoppingManager.AddRentalToShoppingCart(info, 10);
			ShoppingManager.CheckOut(info);
		}

		[TestMethod]
		public void TestCheckOutTwoItems()
		{
			var info = new LoginInfo(1206731771, DateTime.Now, LoginInfo.Role.User);
			ShoppingManager.AddRentalToShoppingCart(info, 10);
			ShoppingManager.AddRentalToShoppingCart(info, 17);
			ShoppingManager.CheckOut(info);
		}

		[TestMethod]
		public void TestCheckOutInsufficientFunds()
		{
			var info = new LoginInfo(1206731771, DateTime.Now, LoginInfo.Role.User);
			ShoppingManager.AddRentalToShoppingCart(info, 14);
			try
			{
				ShoppingManager.CheckOut(info);
			}
			catch (InsufficientFundsException)
			{
				
				//Sucess!
			}
			ShoppingManager.ClearShoppingCart(info);
		}

	    [TestMethod]
	    public void TestChangePurchaseToRent()
	    {
			ShoppingManager.AddPurchaseToShoppingCart(new LoginInfo(1206731771, DateTime.Now, LoginInfo.Role.User), 10);
			ShoppingManager.AddRentalToShoppingCart(new LoginInfo(1206731771, DateTime.Now, LoginInfo.Role.User), 10);
			ShoppingManager.RemoveFromShoppingCart(new LoginInfo(1206731771, DateTime.Now, LoginInfo.Role.User), 10);
	    }

		[TestMethod]
		public void TestPurchaseToToRent()
		{
			ShoppingManager.AddRentalToShoppingCart(new LoginInfo(1206731771, DateTime.Now, LoginInfo.Role.User), 10);
			ShoppingManager.AddPurchaseToShoppingCart(new LoginInfo(1206731771, DateTime.Now, LoginInfo.Role.User), 10);
			ShoppingManager.RemoveFromShoppingCart(new LoginInfo(1206731771, DateTime.Now, LoginInfo.Role.User), 10);
		}

		[TestMethod]
		public void TestCheckoutPurchase()
		{
			var info = new LoginInfo(1206731771, DateTime.Now, LoginInfo.Role.User);
			ShoppingManager.AddPurchaseToShoppingCart(info, 10);
			ShoppingManager.CheckOut(info);
			RentItDatabase.RemoveFromBuyHistory(info.UserId, 10);
		}
    }
}
