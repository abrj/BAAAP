﻿using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Persistence;
using UserManagement;
using Finance;
using System.Numerics;
namespace FinanceTests
{
    [TestClass]
    public class AccountManagerTests
    {
        [TestMethod]
        public void TestSuccesFullDeposit()
        {
            AccountManager.Deposit(100.0, new LoginInfo(1206731771, DateTime.Now, LoginInfo.Role.User), "4697389620852365", 3, 2018, 666, "visa");
        }

        [TestMethod]
        public void TestFailDeposit()
        {
            try
            {
                AccountManager.Deposit(100.0, new LoginInfo(1206731771, DateTime.Now, LoginInfo.Role.User), "1111111111111111", 3, 2018, 666, "visa");
            }
            catch (CreditCardCredentialsException)
            {
                
                //Success!
            }
            
        }

        [TestMethod]
        public void TestConvertCurrency()
        {
            var amount = AccountManager.ConvertCurrencyToRentItCredits(100, "DKK");
			Assert.AreEqual(17, (int)amount);
        }

		[TestMethod]
		public void TestGetTransactionHistory()
		{
			var history = AccountManager.GetTransactionHistory(new LoginInfo(1, DateTime.Now, LoginInfo.Role.User));
		}
    }
}
