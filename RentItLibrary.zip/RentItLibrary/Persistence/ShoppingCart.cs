﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Persistence
{
    public class ShoppingCart
    {
        public List<ShoppingCartItem> Items { get; protected set; }
        public double Total { get; protected set; }
        public ShoppingCart(int userId)
        {
	        Total = 0;
            Items = RentItDatabase.GetShoppingCartItems(userId);
            foreach (var item in Items)
            {
                if (item.PaymentType == "rent") Total += item.Video.Price.RentPrice;
                else Total += item.Video.Price.BuyPrice;
            }
        }
    }
}
