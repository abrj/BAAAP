﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Persistence
{
	public partial class Video
	{
		public double? AverageRating
		{
			get 
			{ 
				var sum = Ratings.Aggregate(0.0, (current, videoRating) => current + videoRating.Rating);
				var average = sum/Ratings.Count;
				if (double.IsNaN(average)) return null;
				return average;
			}
		}
	}
}
