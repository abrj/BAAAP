﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Numerics;

namespace Persistence
{
    public class RentItDatabase
    {

		/// <summary>
		/// Saves a user to the database, if it does not already exist, else does nothing
		/// </summary>
		public static void CreateUser(int id, DateTime birthday, string eMailAddress, string city, string name, string sex)
		{
			using (var Db = new RentItEntityContainer())
			{
				if (UserExists(id)) return;
				var toSave = new RentItUser
					{
						Balance = 0,
						Birthday = birthday,
						EmailAddress = eMailAddress,
						City = city,
						Id = id,
						Name = name,
						Sex = sex,
						Role = "User"
					};

				Db.RentItUsers.Add(toSave);
				Db.SaveChanges(); 
			}
		}

		/// <summary>
		/// Check if user exists in the database
		/// </summary>
		/// <param name="userId"></param>
		/// <returns></returns>
	    public static Boolean UserExists(int userId)
		{
			using (var Db = new RentItEntityContainer())
			{
				return Db.RentItUsers.Any(user => user.Id == userId); 
			}
		}

		/// <summary>
		/// Deletes user if it exists, else does nothing
		/// </summary>
		public static void DeleteUser(int id)
		{
			using (var Db = new RentItEntityContainer())
			{
				if (!UserExists(id)) return;
				var existingUser = Db.RentItUsers.Single(user => user.Id == id);
				Db.RentItUsers.Remove(existingUser);
				Db.SaveChanges(); 
			}
		}

		/// <summary>
		/// Save a rating to the database
		/// </summary>
		public static void SaveRating(int rating, int videoId, int userId)
		{
			using (var Db = new RentItEntityContainer())
			{
				var newRating = new VideoRating
						{
							Rating = rating,
							VideoId = videoId,
							UserId = userId
						};
				Db.Ratings.Add(newRating);
				Db.SaveChanges(); 
			}
		}

		/// <summary>
		/// Remove a rating from the database
		/// </summary>
		public static void DeleteRating(int videoId, int userId)
		{
			using (var Db = new RentItEntityContainer())
			{
				var toRemove = Db.Ratings.Single(rating => rating.UserId == userId && rating.VideoId == videoId);
				Db.Ratings.Remove(toRemove);
				Db.SaveChanges(); 
			}
		}

		/// <summary>
		/// Update the database entry for a user
		/// </summary>
		public static void UpdateUser(int id, string eMailAddress, string city, string name, string sex)
		{
			using (var Db = new RentItEntityContainer())
			{
				var toUpdate = Db.RentItUsers.Single(user => user.Id == id);
				toUpdate.EmailAddress = eMailAddress;
				toUpdate.City = city;
				toUpdate.Name = name;
				toUpdate.Sex = sex;
				Db.SaveChanges(); 
			}

		}

		/// <summary>
		/// Get string representation for the role of user
		/// </summary>
		public static string GetUserRole(int userId)
		{
			using (var Db = new RentItEntityContainer())
			{
				var u = Db.RentItUsers.Single(user => user.Id == userId);
				return u.Role; 
			}
		}

		/// <summary>
		/// Get facebook appid of trusted rentitClient
		/// </summary>
		public static BigInteger GetFacebookAppId(int rentItClientId)
		{
			using (var Db = new RentItEntityContainer())
			{
				var client = Db.TrustedClients.Single(c => c.RentItClientId == rentItClientId);
				return client.FacebookAppId; 
			}
		}

		/// <summary>
		/// Save exception to the database
		/// </summary>
		public static void SaveException(Exception exception)
		{
			using (var Db = new RentItEntityContainer())
			{
				var e = new ExceptionLogEntry
						{
							ExceptionTitle = exception.GetType().Name,
							StackTrace = exception.StackTrace,
							Message = exception.Message,
							TimeStamp = DateTime.Now

						};
				Db.ExceptionLogEntries.Add(e);
				Db.SaveChanges(); 
			}

		}

		/// <summary>
		/// Get a users first and last name seperated by a space
		/// </summary>
        public static string GetUserFirstAndLastName(int userId)
        {
			using (var Db = new RentItEntityContainer())
			{
				RentItUser userFromdb = Db.RentItUsers.Single(user => user.Id == userId);
				var name = userFromdb.Name.Split(' ');
				return name[0] + " " + name[name.Count() - 1]; 
			}
        }

        /// <summary>
        /// Add or subtract from a users balance.
        /// </summary>
        /// <param name="rentItCreditsAmount">The amount to add to the users current balance</param>
        /// <param name="userId"></param>
        public static void AddToUserBalance(double rentItCreditsAmount, int userId)
        {
			using (var Db = new RentItEntityContainer())
			{
				Db.RentItUsers.Single(user => user.Id == userId).Balance += rentItCreditsAmount;
				Db.SaveChanges(); 
			}
        }


		/// <summary>
		/// Save a financial transaction to the database
		/// </summary>
        public static void SaveTransaction(int userId, double rentItCreditsAmount, DateTime timeStamp, int? videoId)
        {
			using (var Db = new RentItEntityContainer())
			{
				var transaction = new FinancialTransaction
						{
							Amount = rentItCreditsAmount,
							User = userId,
							TransactionTimeStamp = timeStamp,
							ForPurchaseOfVideo = videoId
						};
				Db.FinancialTransactions.Add(transaction);
				Db.SaveChanges(); 
			}
        }

		/// <summary>
		/// Add a video to the users shoppingcart, for future purchase as a rent
		/// </summary>
        public static void AddRentalToShoppingCart(int userId, int videoId)
        {
			using (var Db = new RentItEntityContainer())
			{
				var item = new ShoppingCartItem
						{
							PaymentType = "rent",
							UserId = userId,
							VideoId = videoId
						};
				Db.ShoppingCartItems.Add(item);
				Db.SaveChanges(); 
			}
        }

		/// <summary>
		/// Add a video to the users shoppingcart, for future purchase as a buy
		/// </summary>
        public static void AddPurchaseToShoppingCart(int userId, int videoId)
        {
			using (var Db = new RentItEntityContainer())
			{
				var item = new ShoppingCartItem
						{
							PaymentType = "buy",
							UserId = userId,
							VideoId = videoId
						};
				Db.ShoppingCartItems.Add(item);
				Db.SaveChanges(); 
			}
        }

		/// <summary>
		/// Remove video from users shopping cart
		/// </summary>
        public static void RemoveFromShoppingCart(int userId, int videoId)
        {
			using (var Db = new RentItEntityContainer())
			{
				var item = Db.ShoppingCartItems.Single(i => i.UserId == userId && i.VideoId == videoId);
				Db.ShoppingCartItems.Remove(item);
				Db.SaveChanges(); 
			}
        }

		/// <summary>
		/// Empty shoppingcart for a user
		/// </summary>
        public static void ClearShoppingCart(int userId)
        {
			using (var Db = new RentItEntityContainer())
			{
				var items = Db.ShoppingCartItems.Where(item => item.UserId == userId);

				foreach (var item in items)
				{
					Db.ShoppingCartItems.Remove(item);
				}
				Db.SaveChanges(); 
			}
        }

		/// <summary>
		/// Get all items in users shopping cart
		/// </summary>
        public static List<ShoppingCartItem> GetShoppingCartItems(int userId)
        {
			using (var Db = new RentItEntityContainer())
			{
				return Db.ShoppingCartItems.Where(i => i.UserId == userId).Include(i => i.Video).Include(i => i.Video.Price).Include(i => i.Video.Ratings).ToList(); 
			}
        }

		/// <summary>
		/// Get balance from user
		/// </summary>
        public static double GetUserbalance(int userId)
        {
			using (var Db = new RentItEntityContainer())
			{
				return Db.RentItUsers.Single(user => user.Id == userId).Balance; 
			}
        }

		/// <summary>
		/// Add information about a rental purchase to the database
		/// </summary>
        public static void AddToRentHistory(int userId, int videoId, DateTime rentDate)
        {
			using (var Db = new RentItEntityContainer())
			{
				var rent = new RentalInformation
						{
							RentDate = rentDate,
							UserId = userId,
							VideoId = videoId
						};
				Db.Rents.Add(rent);
				Db.SaveChanges(); 
			}
        }

		/// <summary>
		/// Add purchase to buy history of user
		/// </summary>
        public static void AddToBuyHistory(int userId, int videoId, DateTime purchaseDate)
        {
			using (var Db = new RentItEntityContainer())
			{
				var purchase = new Purchase
						{
							UserId = userId,
							VideoId = videoId,
							PurchaseDate = purchaseDate
						};
				Db.Purchaces.Add(purchase);
				Db.SaveChanges(); 
			}
        }

		/// <summary>
		/// Test if a video is already in the users cart
		/// </summary>
		public static bool ItemInCart(int userId, int videoId)
		{
			using (var Db = new RentItEntityContainer())
			{
				return Db.ShoppingCartItems.Any(i => i.UserId == userId && i.VideoId == videoId); 
			}
		}

		/// <summary>
		/// Check if users cart is empty
		/// </summary>
		public static bool CartIsEmpty(int userId)
		{
			using (var Db = new RentItEntityContainer())
			{
				return !Db.ShoppingCartItems.Any(i => i.UserId == userId); 
			}
		}

		/// <summary>
		/// Get item from shopping cart for user
		/// </summary>
		public static ShoppingCartItem GetCartItem(int userId, int videoId)
		{
			using (var Db = new RentItEntityContainer())
			{
				return Db.ShoppingCartItems.Single(r => r.UserId == userId && r.VideoId == videoId); 
			}
		}

		public static List<FinancialTransaction> GetTransactionHistory(int userId)
		{
			using (var Db = new RentItEntityContainer())
			{
				return Db.FinancialTransactions.Where(ft => ft.User == userId).Include(ft => ft.Video).ToList(); 
			}
		}

		public static string GetPermanentPathToVideo(int videoId)
		{
			using (var Db = new RentItEntityContainer())
			{
				return Db.Videos.Single(v => v.Id == videoId).VideoPath; 
			}
		}

	    public static RentalInformation GetNewestRentalInformation(int userId, int videoId)
	    {
			using (var Db = new RentItEntityContainer())
			{
				var infos = Db.Rents.Where(ri => ri.UserId == userId && ri.VideoId == videoId);
				var newest = new RentalInformation
					{
						RentDate = DateTime.MinValue,
					};
				foreach (var rentalInformation in infos)
				{
					if (rentalInformation.RentDate > newest.RentDate)
						newest = rentalInformation;
				}
				return newest; 
			}
	    }

	    public static void IncrementStreamCount(int videoId)
	    {
			using (var Db = new RentItEntityContainer())
			{
				var video = Db.Videos.Single(v => v.Id == videoId);
				video.StreamCount++;
				Db.SaveChanges(); 
			}
	    }

	    public static List<RentalInformation> GetRenthistory(int userId)
	    {
			using (var Db = new RentItEntityContainer())
			{
				return Db.Rents.Where(ri => ri.UserId == userId).ToList(); 
			}
	    }

		public static void RemoveFromBuyHistory(int userId, int videoId)
		{
			using (var Db = new RentItEntityContainer())
			{
				var purchase = Db.Purchaces.Single(p => p.UserId == userId && p.VideoId == videoId);
				Db.Purchaces.Remove(purchase);
				Db.SaveChanges(); 
			}
		}

	    public static List<Video> GetAllVideos()
	    {
			using (var Db = new RentItEntityContainer())
			{

				return Db.Videos.Select(v => v).Include(v => v.Ratings).ToList();
			}
	    }

		public static List<Video> GetHighestRatedVideos()
		{
			using (var Db = new RentItEntityContainer())
			{
				var videos = from video in Db.Videos
							 select video;
				var list = videos.ToList();
				return list.OrderByDescending(v => v.AverageRating).Take(10).ToList(); 
			}
		}

		/// <summary>
		/// Get a vdieo from the database
		/// </summary>
	    public static Video GetVideo(int videoId)
	    {
			using (var Db = new RentItEntityContainer())
			{
				return Db.Videos.Where(v => v.Id == videoId).Include(v => v.Ratings).Single();
			}
	    }

		/// <summary>
		///  Test if a user has payed for a video
		/// </summary>
        public static bool HasUserPayedForVideo(int videoId, int userId)
        {
			using (var Db = new RentItEntityContainer())
			{
				return Db.Purchaces.Any(p => p.UserId == userId && p.VideoId == videoId); 
			}
        }


		/// <summary>
		/// Get a user from the database
		/// </summary>
	    public static RentItUser GetUser(int userId)
	    {
			using (var Db = new RentItEntityContainer())
			{
				return Db.RentItUsers.Single(u => u.Id == userId); 
			}
	    }


		/// <summary>
		/// Get all users in the database
		/// </summary>
	    public static List<RentItUser> GetAllUsers()
	    {
			using (var Db = new RentItEntityContainer())
			{
				return Db.RentItUsers.ToList(); 
			}
	    }


		/// <summary>
		/// Get 10 newest videos from the database, based on upload date
		/// </summary>
		public static List<Video> GetNewVideos()
		{
			using (var Db = new RentItEntityContainer())
			{
				return Db.Videos.OrderByDescending(v => v.Owner.UploadDate).Include(v => v.Ratings).Take(10).ToList();
			}
		}

		/// <summary>
		/// Delete video database entry. Does NOT delete it on the disk
		/// </summary>
	    public static void DeleteVideo(int videoId)
	    {
			using (var Db = new RentItEntityContainer())
			{
				var video = Db.Videos.Single(v => v.Id == videoId);
				Db.Videos.Remove(video);
				Db.SaveChanges(); 
			}
	    }


		/// <summary>
		/// Add database reference to a video
		/// </summary>
		public static int CreateVideo(string title, string description, string videoPath, string thumbPath, double length, string category, string priceCategory, int streamCount, string fileType, string thumbnailType)
		{
			using (var Db = new RentItEntityContainer())
			{
				var video = new Video
						{
                            Title = title,
                            Description = description,
                            VideoPath = "",
                            ThumbPath = "",
                            Length = length,
                            Category = category,
                            PriceCategory = priceCategory,
                            StreamCount = streamCount,
                            FileType = fileType
						};
				Db.Videos.Add(video);
                Db.SaveChanges();
                //Need to save the video in the database, before the videoId is set, which is used for the filename 
				video.VideoPath = "http://rentit.itu.dk/RentIt30/MEDIA/" + video.Id + video.FileType;
                video.ThumbPath = "http://rentit.itu.dk/RentIt30/MEDIA/thumbnails/"+video.Id+thumbnailType;
			    //Updates the paths for the video and thumbnail
                Db.SaveChanges();
			    return video.Id;
			}
		}

		public static bool VideoExists(int videoId)
		{
			using (var Db = new RentItEntityContainer())
			{
				return Db.Videos.Any(v => v.Id == videoId); 
			}
		}

		public static List<Video> SearchForVideo(String searchString)
		{
			using (var db = new RentItEntityContainer())
			{
				return db.Videos.Where(v => v.Title.Contains(searchString) || v.Description.Contains(searchString)).Include(v => v.Ratings).ToList();
			}
		}

		public static List<Video> GetRentHistory(int userId, TimeSpan rentPeriod)
		{
			using (var Db = new RentItEntityContainer())
			{
				var rents = Db.Rents.Where(r => r.UserId == userId).Include(p => p.Video.Price).Include(p => p.Video.Ratings);
				var vs = new List<Video>();
				foreach (var rentalInformation in rents)
				{
					if(DateTime.Now - rentalInformation.RentDate < rentPeriod)
					vs.Add(rentalInformation.Video);
				}
				return vs;
			}
			
		}

		public static List<Video> GetBuyHistory(int userId)
		{
			using (var Db = new RentItEntityContainer())
			{
				var purchases = Db.Purchaces.Where(p => p.UserId == userId).Include(p => p.Video.Price).Include(p => p.Video.Ratings);
				var vs = new List<Video>();
				foreach (var purchase in purchases)
				{
					vs.Add(purchase.Video);
				}
				return vs;
			}
			
		}
    }
}
