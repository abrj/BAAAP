﻿using System;
using System.Collections.Generic;
using System.IO;
using Persistence;
using UserManagement;

namespace VideoManagement
{
	public class VideoManager
	{
		private static readonly TimeSpan RentTimeLimit = new TimeSpan(24,00,00);

		public static Stream CreateStream(LoginInfo userInfo, int videoId)
		{
			try
			{
				var rentInfo = RentItDatabase.GetNewestRentalInformation(userInfo.UserId, videoId);
				if (DateTime.Now - rentInfo.RentDate > RentTimeLimit)
					throw new RentPeriodExceededException("The users rent period for this video has expired");

				RentItDatabase.IncrementStreamCount(videoId);

				var path = RentItDatabase.GetPermanentPathToVideo(videoId);


				return new FileStream(path, FileMode.Open);
			}
			catch (InvalidOperationException)
			{

				throw new NoRentalInformationFoundException("No rental information could be found for user: " + userInfo.UserId +
				                                            " and video: " + videoId);
			}

		}

        public static string CreateDownloadLink(LoginInfo userInfo, int videoId)
        {
            string url = "http://rentit.itu.dk/RentIt30/MEDIA/";
           
                if (RentItDatabase.HasUserPayedForVideo(videoId,userInfo.UserId))
                {
                    Video video = RentItDatabase.GetVideo(videoId);
                    string id = video.Id.ToString();
                    string type = video.FileType;
                    string videoLink = url + id + type;
                    return videoLink;

                }
                    
                    throw new NoPurchaseInformationFoundException("No purchase information cound be found for user: " +
                                            userInfo.UserId + " and video: " + videoId);
  
            
        }

	    public static void RateVideo(LoginInfo userInfo, int videoId, int rating)
		{
			RentItDatabase.SaveRating(rating, videoId, userInfo.UserId);
		}

		public static List<Video> GetAllVideos()
		{
			return RentItDatabase.GetAllVideos();
		}

		public static List<Video> GetActiveRentHistory(int userId)
		{
			return RentItDatabase.GetRentHistory(userId, RentTimeLimit);
		}

		public static List<Video> GetBuyHistory(int userId)
		{
			return RentItDatabase.GetBuyHistory(userId);
		} 

		public static List<Video> GetHighestRatedVideos()
		{
			return RentItDatabase.GetHighestRatedVideos();
		}


        public static List<Video> GetVideosByKeyWord(string keyword)
        {
            return RentItDatabase.SearchForVideo(keyword);
        }

		public static List<Video> GetNewVideos()
		{
			return RentItDatabase.GetNewVideos();
		}

		public static void DeleteVideo(int videoId)
		{
			RentItDatabase.DeleteVideo(videoId);
		}

	    public static void SaveVideo(string title, string description, double length, string category, string priceCategory, string fileType, Stream video, Stream thumbnail, string thumbnailType)
	    {
            //Path to files
	        long lenght = video.Length;
            string videoPath = @"..\..\..\RentitServices\RentIt30\MEDIA\";
            string thumbPath = @"..\..\..\RentitServices\RentIt30\MEDIA\thumbnails";
            //Stream count is always said to 0
	        int streamCount = 0;

            //Save the video in the database using the Video object
            int videoId = RentItDatabase.CreateVideo(title,description, videoPath, thumbPath, length, category, priceCategory, streamCount, fileType, thumbnailType);
            
	        
	        //Save the video to disk
	        string videoPathWithName = videoPath + videoId + fileType;
            FileStream videofile = new FileStream(videoPathWithName, FileMode.Create, System.IO.FileAccess.Write);
            byte[] bytes = new byte[video.Length];
            video.Read(bytes, 0, (int)video.Length);
            videofile.Write(bytes, 0, bytes.Length);
            videofile.Close();
            video.Close();
            
            //Save the thumbnail to disk
            string thumbPathWithName = thumbPath + thumbnail + thumbnailType;
            FileStream thumbfile = new FileStream(thumbPathWithName, FileMode.Create, System.IO.FileAccess.Write);
            byte[] thumbbytes = new byte[thumbnail.Length];
            video.Read(bytes, 0, (int)thumbnail.Length);
            thumbfile.Write(bytes, 0, thumbbytes.Length);
            thumbfile.Close();
            thumbnail.Close(); 
	    }

	}
}
