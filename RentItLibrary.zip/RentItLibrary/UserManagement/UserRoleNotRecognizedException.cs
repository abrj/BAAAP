﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace UserManagement
{
	class UserRoleNotRecognizedException : Exception
	{
		public UserRoleNotRecognizedException(string message) : base(message)
		{}
	}
}
