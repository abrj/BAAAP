﻿

namespace UserManagement
{
	public class Authorization
	{
		/// <summary>
		/// Test if a logged in user is an administrator
		/// </summary>
		public static bool IsAdministrator(LoginInfo loginInfo)
		{
			return loginInfo.UserRole == LoginInfo.Role.Administrator;
		}
	}
}
