﻿using System;
using System.Collections.Generic;
using System.Numerics;
using Facebook;
using System.Net;
using System.IO;
using Newtonsoft.Json;

namespace UserManagement
{
    public class Authentication

    {
		private static readonly Dictionary<string,LoginInfo> LoginCollection  = new Dictionary<string, LoginInfo>();

		/// <summary>
		/// Authenticate a user using a facebooktoken and a trusted client Id
		/// </summary>
	    public static bool Authenticate(String facebookToken, int rentItClientId)
	    {
		    bool userAuthenticated;
		    bool appAuthenticated;
		    try
		    {
				appAuthenticated = AuthenticateApp(facebookToken, rentItClientId);
				userAuthenticated = AuthenticateUser(facebookToken);
		    }
		    catch (WebException)
		    {
			    throw new InvalidTokenException("Token could not be used to verify that the calling client was trusted." + 
												"Either the app id is not trusted by RentIt or the Facebook accesstoken was malformed");
		    }
		    catch (FacebookOAuthException)
		    {
			    throw new InvalidTokenException("Token could not be used to verify user. Either the token was malformed, or it has expired");

		    }
		    catch (NullReferenceException)
		    {
				throw new InvalidTokenException("Token did not grant required user permissions. Tokens are required to grant access to: Emailadress, location, birthday and gender");
		    }

         

		    return userAuthenticated && appAuthenticated;
	    }

		//Authenticate that the app who obtained the token is trusted
	    private static bool AuthenticateApp(string facebookToken, int clientId)
	    {
		    var facebookAppResult = GetAppInformationFromFacebook(facebookToken);
		    return facebookAppResult.Id == Persistence.RentItDatabase.GetFacebookAppId(clientId);
	    }

		//Authenticate that the user has granted permissions to access his information
	    private static bool AuthenticateUser(string facebookToken)
	    {
		    var faceBookUserResult = GetUserInformationFromFacebook(facebookToken);
		    SaveUser(faceBookUserResult);
		    AddToLoginCollection(facebookToken, faceBookUserResult);
		    return true;
	    }

	    private static void SaveUser(FacebookUserResult faceBookUserResult)
	    {
			//If the user has logged in in the past
		    if (Persistence.RentItDatabase.UserExists(faceBookUserResult.Id))
			    Persistence.RentItDatabase.UpdateUser(
				    faceBookUserResult.Id,
				    faceBookUserResult.EMailAddress,
				    faceBookUserResult.City,
				    faceBookUserResult.Name,
				    faceBookUserResult.Sex
				    );
				
			//if its a new user
		    else
			    Persistence.RentItDatabase.CreateUser(
				    faceBookUserResult.Id,
				    faceBookUserResult.Birthday,
				    faceBookUserResult.EMailAddress,
				    faceBookUserResult.City,
				    faceBookUserResult.Name,
				    faceBookUserResult.Sex
				    );
	    }

		/// <summary>
		/// Verify that the user is logged in
		/// </summary>
	    public static LoginInfo Validate(string facebookToken)
	    {
		    LoginInfo loginInfo;
		    LoginCollection.TryGetValue(facebookToken, out loginInfo);
			if (loginInfo == null) throw new UserNotLoggedInException();
			return loginInfo;
	    }

		/// <summary>
		/// Log user out
		/// </summary>
		public static void LogOut(string facebooktoken)
		{
			LoginCollection.Remove(facebooktoken);
		}

		//Add user to collection of users who are logged in
	    private static void AddToLoginCollection(string facebookToken, FacebookUserResult faceBookUserResult)
	    {
			var roleFromDb = Persistence.RentItDatabase.GetUserRole(faceBookUserResult.Id);
		    LoginInfo.Role role;
		    if (!Enum.TryParse(roleFromDb, out role))
			    throw new UserRoleNotRecognizedException("The following role obtained from the RentIt database for user: " + faceBookUserResult.Id + "," +
			                                             " could not be understood as a RentIt user role: " + roleFromDb);
		    var info = new LoginInfo(faceBookUserResult.Id, DateTime.Now, role);

			try
			{
				LoginCollection.Add(facebookToken, info);
			}
			catch (ArgumentException)
			{
				
				Console.Out.WriteLine("User already logged in");
			}
	    }

	
		/// Get app information from facebook
		private static FacebookAppResult GetAppInformationFromFacebook(string facebookToken)
		{
			//url to facebook api for getting app id from facebook token
			var url = "https://graph.facebook.com/app/?access_token=" + facebookToken;
			//make request
			var request = WebRequest.Create(url);
			request.ContentType = "application/json; charset=utf-8";
			string json;
			var response = (HttpWebResponse)request.GetResponse();
			//read response
			using (var sr = new StreamReader(response.GetResponseStream()))
			{
				json = sr.ReadToEnd();
			}
			//deserialize response for easier access to data
			dynamic result = JsonConvert.DeserializeObject(json);
			Console.Out.WriteLine();
			return new FacebookAppResult
				{
					Id = BigInteger.Parse((string) result.id)
				};
		}

		// Get user information from facebook
		private static FacebookUserResult GetUserInformationFromFacebook(string facebookToken)
		{
			var client = new FacebookClient(facebookToken);
			dynamic me = client.Get("me");
			var result = new FacebookUserResult
				{
					Id = int.Parse(me.id),
					EMailAddress = me.email,
					Name = me.name,
					City = me.location.name,
					Sex = me.gender,
					Birthday = ParseBirthday(me.birthday)
				};
			return result;
		}

		
		// Parse the birthday result from facebook from a string to a dateTime object
		private static DateTime ParseBirthday(String birthday)
		{
			var split = birthday.Split('/');
			var year = int.Parse(split[2]);
			var month = int.Parse(split[0]);
			var day = int.Parse(split[1]);
			return new DateTime(year,month,day);
		}

		// Helper class for transporting data recieved from facebook
		internal class FacebookUserResult
		{
			internal int Id { get; set; }
			internal String EMailAddress { get; set; }
			internal String Name { get; set; }
			internal String City { get; set; }
			internal String Sex { get; set; }
			internal DateTime Birthday { get; set; }
		}

		// Helper class for transporting data recieved from facebook
		internal class FacebookAppResult
		{
			internal BigInteger Id { get; set; }
		}

        //For adding a Test user to the Dictinary for validation
        public static void AddTestUser()
        {
            var info = new LoginInfo(0, DateTime.Now, LoginInfo.Role.Administrator);
            try
            {
                LoginCollection.Add("ABC", info);
            }
            catch (ArgumentException)
            {
                //Already in map
            }
        }
    }
}
