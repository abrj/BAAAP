﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Persistence;

namespace UserManagement
{
	public class UserManager
	{
		public static RentItUser GetUser(LoginInfo userinfo)
		{
			return RentItDatabase.GetUser(userinfo.UserId);
		}

		public static RentItUser GetUser(int userId)
		{
			return RentItDatabase.GetUser(userId);
		}

		public static List<RentItUser> GetAllUsers()
		{
			return RentItDatabase.GetAllUsers();
		}

		public static void DeleteUser(int userId)
		{
			RentItDatabase.DeleteUser(userId);
		}
	}
}
