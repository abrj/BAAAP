﻿using System;

namespace UserManagement
{
	public class LoginInfo
	{
		public readonly int UserId;
		public readonly DateTime LoginTime;
		public readonly Role UserRole;

		public LoginInfo(int userId, DateTime loginTime, Role role)
		{
			UserId = userId;
			LoginTime = loginTime;
			UserRole = role;
		}

		public enum  Role { User, Administrator }
	}
}
