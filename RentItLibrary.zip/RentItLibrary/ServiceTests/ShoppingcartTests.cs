﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using MyService;
using Persistence;
using UserManagement;

namespace ServiceTests
{
    [TestClass]
    public class ShoppingcartTests
    {
        //AddRental/Purchase, Remove, Clear, Checkout

        [ClassInitialize]
        public static void Init(TestContext context)
        {
            Authentication.AddTestUser();
            RentItDatabase.CreateUser(0, new DateTime(2020, 2, 2), "FunkyTown", "lurk@lurk.com", "Lurk Lurkby", "lurk");

        }

        [ClassCleanup]
        public static void Cleanup()
        {
            RentItDatabase.DeleteUser(0);
            Service.Logout("ABC");
        }

        public static MyMethod Service = new MyMethod();

        [TestMethod]
        public void TestAddRentalToShoppingCart()
        {
            var cart =
                Service.AddRentalToShoppingCart(
                    "ABC",
                    10);

            Assert.AreEqual(cart.Items[0].VideoId, 10);
            Service.ClearShoppingCart("ABC");
        }

        [TestMethod]
        public void TestAddPurchaseToShoppingCart()
        {
            var cart =
                Service.AddPurchaseToShoppingCart(
                    "ABC",
                    10);

            Assert.AreEqual(cart.Items[0].VideoId, 10);
            Service.ClearShoppingCart("ABC");
        }

        [TestMethod]
        public void TestCheckOut()
        {
            Service.AddPurchaseToShoppingCart("ABC", 10);
            Service.DepositCredits("ABC", 10000, "4697389620852365", 3, 2018, 666, "visa");
            Double before = RentItDatabase.GetUserbalance(0);
            Service.CheckoutShoppingCart("ABC");
            Double after = RentItDatabase.GetUserbalance(0);
            Assert.IsTrue(RentItDatabase.HasUserPayedForVideo(10, 0));
            Assert.IsTrue(after<=before);
            RentItDatabase.RemoveFromBuyHistory(0, 10);
        }

        [TestMethod]
        public void TestClearShoppingCart()
        {
            Service.AddPurchaseToShoppingCart("ABC", 10);
            Service.ClearShoppingCart("ABC");
            var info = Authentication.Validate("ABC");
            Assert.IsTrue(RentItDatabase.CartIsEmpty(info.UserId));
        }

        [TestMethod]
        public void TestRemoveFromShoppingCart()
        {
            Service.AddPurchaseToShoppingCart("ABC", 10);
            Service.RemoveVideoFromShoppingCart("ABC", 10);
            var info = Authentication.Validate("ABC");
            Assert.IsTrue(RentItDatabase.CartIsEmpty(info.UserId));
        }
    }
}
