﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using MyService;
using Persistence;
using UserManagement;

namespace ServiceTests
{
    [TestClass]
    public class AuthenticateTests
    {
        [ClassInitialize]
        public static void Init(TestContext context)
        {
            Authentication.AddTestUser();
            RentItDatabase.CreateUser(0, new DateTime(2020, 2, 2), "FunkyTown", "lurk@lurk.com", "Lurk Lurkby", "lurk");

        }

        [ClassCleanup]
        public static void Cleanup()
        {
            RentItDatabase.DeleteUser(0);
            Service.Logout("ABC");
        }

        public static MyMethod Service = new MyMethod();

        public string ValidToken =
            "AAACEdEose0cBAJBW9QC3KdtoLZCFi4uCIhLr5zxZBDuKHMU1wpZCGnZBnHuq1ZBJHeAldZBsB19mVieHGuewWb2EzGfIF9iyZCRcwytKJ9WNlaKdwyTvBzh";
        
        [TestMethod]
        public void TestLoginWithFacebook()
        {
            Service.LoginWithFacebook(ValidToken, 123456);
            var info =
                Authentication.Validate(
                    ValidToken);
            Assert.AreEqual(info.UserId, 1206731771);
        }

        [TestMethod]
        public void TestLoginWithFacebookWrongToken()
        {
            
        }

        [TestMethod]
        public void TestLoginWithFacebookExpiredToken()
        {
            
        }

        [TestMethod]
        public void TestLoginWithFacebookMissingInfoInToken()
        {
            
        }

        [TestMethod]
        public void TestLoginWithFacebookWrongRentitClientId()
        {
            
        }

        [TestMethod]
        public void TestLogOut()
        {
			Service.LoginWithFacebook(ValidToken, 123456);
			Service.Logout(ValidToken);
			try
			{
				Authentication.Validate(
					ValidToken);
			}
			catch (UserNotLoggedInException)
			{
				//Sucess!
            }
            Assert.Fail();
        }
    }
}
