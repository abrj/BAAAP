﻿using System;
using System.IO;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using MyService;
using MyService.DataContractClasses;

namespace ServiceTests
{
    [TestClass]
    public class UploadTest
    {
        [TestMethod]
        public void Upload()
        {
            var service = new MyMethod();
            string token =
                "CAACEdEose0cBAB0ec4GbjGhuUvbJzaImZAZB8AFjUF1HJPA2r0lP3yjhtGIvZB8Fd2RAdRjcMGLIrilyHxbC3yaYgagfIpwhf940uLZBsLPAoG2zk3XnsjZCRWV7xoOkm4Q0rzvqsh5IS26bCxhtBvZAlyZCZCl0d9QZD";
            service.LoginWithFacebook(token, 234567);
            string filePath = @"C:\UploadTest\lol.mp4";
            
            using (FileStream stream = new FileStream(filePath, FileMode.Open))
            {
                var upload = new VideoUpload();
                upload.Token = token;
                upload.Video = stream;
                upload.Thumbnail = stream;
                var info = new VideoInfo();
                info.VideoTitle = "UploadTestTitleTODAY";
                info.Description = "TODAYUPLOAD TEST VIDEO";
                info.Length = 99.9;
                info.Category = "Test";
                info.PriceCategory = "Free";
                info.VideoType = ".mp4";

                upload.ThumbnailType = ".thumb";
                upload.VideoInfo = info;


                Console.Out.WriteLine("STARTED TO UPLOAD");
                service.UploadVideo(upload);
                Console.Out.WriteLine("FINISHED UPLOADING");
                stream.Close();
            }
        }
    }
}
