﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using MyService;
using MyService.DataContractClasses;
using Persistence;
using UserManagement;

namespace ServiceTests
{
    [TestClass]
    public class VideoTests
    {
        //StremVideo, DownloadVideo and RateVideo

        //GetAll, HighestRated, Recommended, GetNew
        //...

        [ClassInitialize]
        public static void Init(TestContext context)
        {
            Authentication.AddTestUser();
            RentItDatabase.CreateUser(0, new DateTime(2020, 2, 2), "FunkyTown", "lurk@lurk.com", "Lurk Lurkby", "lurk");

        }

        [ClassCleanup]
        public static void Cleanup()
        {
            RentItDatabase.DeleteUser(0);
            Service.Logout("ABC");
        }

        public static MyMethod Service = new MyMethod();

        [TestMethod]
        public void TestStreamVideo()
        {
            Service.AddRentalToShoppingCart("ABC", 10);
            Service.CheckoutShoppingCart("ABC");
            var stream = Service.StreamVideo("ABC", 10);
            Assert.IsNotNull(stream);
        }

        [TestMethod]
        public void TestStreamVideoRentExpired()
        {
            
        }

        [TestMethod]
        public void TestStreamVideoNotRented()
        {
            
        }

        [TestMethod]
        public void TestStreamVideoNotFound()
        {
            
        }

		[TestMethod]
		public void TestGetBuyHistory()
		{
			Service.GetBuyHistory("ABC");
		}

		[TestMethod]
		public void TestGetRentHistory()
		{
			Service.GetRentHistory("ABC");
		}

        [TestMethod]
        public void TestDownloadVideo()
        {

        }
        
        [TestMethod]
        public void TestDownloadVideoNotBought()
        {

        }

        [TestMethod]
        public void TestDownloadVideoNotFound()
        {

        }

        [TestMethod]
        public void TestUploadVideo()
        {
            //NOT DONE 
            var video = new VideoUpload();
            video.Token = ("ABC");
           // video.Video = //Stream goes here
             //   video.Thumbnail = //Stream goes here
                //VideoInfo info = new VideoInfo();



                //Service.UploadVideo(video);
                Assert.AreEqual(true, true);
        }

        [TestMethod]
        public void TestRateVideo()
        {
            Service.RateVideo("ABC", 5, 10);
            RentItDatabase.DeleteRating(10, 0);
        }

        [TestMethod]
        public void TestRateVideoRatingOutOfBound()
        {
            
        }

        [TestMethod]
        public void TestRateVideoVideoNotFound()
        {
            
        }

        [TestMethod]
        public void TestGetNewVideos()
        {
            var videos = Service.GetNewVideos();
            foreach (var videoInfo in videos)
            {
                Assert.IsNotNull(videoInfo.VideoId);
            }
        }

        [TestMethod]
        public void TestGetAll()
        {
            var videos = Service.GetAllVideos();
            foreach (var videoInfo in videos)
            {
                Assert.IsNotNull(videoInfo.VideoId);
            }
        }

        [TestMethod]
        public void TestRecommendedVideos()
        {
            var videos = Service.GetRecommendedVideos();
            foreach (var videoInfo in videos)
            {
                Assert.IsNotNull(videoInfo.VideoId);
            }
        }

        [TestMethod]
        public void TestGetHighestRated()
        {
            var videos = Service.GetRecommendedVideos();
            foreach (var videoInfo in videos)
            {
                Assert.IsNotNull(videoInfo.VideoId);
            }
        }
    }
}
