﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using MyService;
using Persistence;
using UserManagement;

namespace ServiceTests
{
    [TestClass]
    public class FinancialTests
    {
        //Deposit and ConvertCurrency, GetTransactionHistory

        [ClassInitialize]
        public static void Init(TestContext context)
        {
            Authentication.AddTestUser();
            RentItDatabase.CreateUser(0, new DateTime(2020, 2, 2), "FunkyTown", "lurk@lurk.com", "Lurk Lurkby", "lurk");

        }

        [ClassCleanup]
        public static void Cleanup()
        {
            RentItDatabase.DeleteUser(0);
            Service.Logout("ABC");
        }

        public static MyMethod Service = new MyMethod();

        [TestMethod]
        public void TestDeposit()
        {
            var before = RentItDatabase.GetUserbalance(0);
            Service.DepositCredits("ABC", 100, "4697389620852365", 3, 2018, 666, "visa");
            var after = RentItDatabase.GetUserbalance(0);
            Assert.AreEqual(after, before + 100);
        }

        [TestMethod]
        public void TestConvertCredits()
        {
            Assert.IsNotNull(Service.ConvertCredits(100, "DKK"));
        }

        [TestMethod]
        public void TestGetTransationhistory()
        {
            RentItDatabase.SaveTransaction(0,100.0,new DateTime(2020,2,2),10);
            var history = Service.GetTransactionHistory("ABC");
            foreach (var transaction in history)
            {
                if (transaction.TransactionDate.Equals(new DateTime(2020, 2, 2)))
                Assert.IsNotNull(transaction.Amount.Equals(100.0));
            }
        }
    }
}
