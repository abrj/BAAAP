﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using MyService;
using Persistence;
using UserManagement;

namespace ServiceTests
{
    [TestClass]
    public class AdminTests
    {
        //IsAdministrator, GetAllUsers, GetUser, DeleteUser, DeleteVideo

        [ClassInitialize]
        public static void Init(TestContext context)
        {
            Authentication.AddTestUser();
            RentItDatabase.CreateUser(0, new DateTime(2020, 2, 2), "lurk@lurk.com", "FunkyTown", "Lurk Lurkby", "lurk");

        }

        [ClassCleanup]
        public static void Cleanup()
        {
            RentItDatabase.DeleteUser(0);
            Service.Logout("ABC");
        }

        public static MyMethod Service = new MyMethod();
        
        [TestMethod]
        public void TestGetUser()
        {
            var user = Service.GetUser("ABC");
            Assert.AreEqual("Lurk Lurkby", user.Name);
        }

        [TestMethod]
        public void TestGetOtherUser()
        {
            var user = Service.GetOtherUser("ABC", 586021925);
            Assert.AreEqual(user.Id, 586021925);
        }

        [TestMethod]
        public void TestAllUsers()
        {
            var users = Service.GetAllUsers("ABC");
            foreach (var userInfo in users)
            {
                Assert.IsNotNull(userInfo.Id);
            }
        }

        [TestMethod]
        public void TestDeleteUser()
        {
            RentItDatabase.CreateUser(-1, DateTime.Now, "lurk@lurk.com", "Lurkby", "Lurk Lurk", "lurk");
            Service.DeleteUser("ABC", -1);
            Assert.IsFalse(RentItDatabase.UserExists(-1));
        }

        [TestMethod]
        public void TestDeleteVideo()
        {
            var videoId = RentItDatabase.CreateVideo("lolTile", "lolDesc", "TESTDIR", "TESTTHUMBDIR", 0.0, "Test", "Free", 0, ".mp4",".thumbLOl");
            Service.DeleteVideo("ABC", videoId);
            Assert.IsFalse(RentItDatabase.VideoExists(videoId));
        }
    }
}
