﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Finance;
using UserManagement;
using System.Numerics;

namespace LibraryDebugClient
{
	class MainClass
	{
		static void Main(string[] args)
		{
		    Console.Out.WriteLine(AccountManager.ConvertCurrencyToRentItCredits(100, "DKK"));
		    Console.In.Read();
		}
	}
}
