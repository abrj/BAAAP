﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Finance
{
    public class CreditCardCredentialsException : Exception
	{
		public CreditCardCredentialsException(string message) : base(message) {}
	}
}
