﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using PayPal;
using PayPal.Api.Payments;
using PayPal.Exception;
using Persistence;
using UserManagement;
using System.Numerics;

namespace Finance
{
	public class AccountManager
	{
        /// <summary>
        /// Convert currency to RentItCredits. RentItCredits are fixed to US Dollars
        /// </summary>
        public static float ConvertCurrencyToRentItCredits(double amount, string currency)
        {
            //url for googles currency converter from USD to RentItCredit
            var url = "http://www.google.com/ig/calculator?hl=en&q=" + amount.ToString() + currency.ToUpper() + "=?USD";
			//make request
			var request = WebRequest.Create(url);
			request.ContentType = "application/json; charset=utf-8";
			string json;
			var response = (HttpWebResponse)request.GetResponse();
			//read response
			using (var sr = new StreamReader(response.GetResponseStream()))
			{
				json = sr.ReadToEnd();
			}

            //deserialize response for easier access to data
            dynamic result = JsonConvert.DeserializeObject(json);
            Console.Out.WriteLine();
            string rhs = result.rhs;
            var split = rhs.Split(' ');
            return float.Parse(split[0]);

        }
		/// <summary>
		/// Deposit rentit credits to a users account
		/// </summary>
		public static void Deposit(double rentItCreditsAmount, LoginInfo userLoginInfo, string cardNumber, int expMonth, int expYear,
		                           int securityNumber, string cardType)
		{
			//Obtaining token
			var token = GetOAuthToken();
			//Get username
			var splitName = GetName(userLoginInfo);
			//Set credit card information
			var creditCard = new CreditCard
			{
				number = cardNumber,
				type = cardType,
				expire_month = expMonth.ToString(CultureInfo.InvariantCulture),
				expire_year = expYear.ToString(CultureInfo.InvariantCulture),
				first_name = splitName[0],
				last_name = splitName[1]
			};

			var payment = CreatePayment(rentItCreditsAmount, creditCard);

		    try
			{
				var createdPayment = payment.Create(token);
			    if (createdPayment.state == "approved") UpdateBalance(rentItCreditsAmount, userLoginInfo);
			}
			catch (PayPalException)
			{
				throw new CreditCardCredentialsException("The provided credit card information was either incorrect," +
				                                       " or the payment was rejected by the creditcard provider");
			}
		}

	    private static void UpdateBalance(double rentItCreditsAmount, LoginInfo userLoginInfo)
	    {
	        RentItDatabase.AddToUserBalance(rentItCreditsAmount, userLoginInfo.UserId);
	        RentItDatabase.SaveTransaction(userLoginInfo.UserId, rentItCreditsAmount, DateTime.Now, null);
	    }

	    private static Payment CreatePayment(double rentItCreditsAmount, CreditCard creditCard)
	    {
	        var amountDetails = new AmountDetails {subtotal = rentItCreditsAmount.ToString(), tax = "0.00", shipping = "0.00"};
	        var amount = new Amount {total = rentItCreditsAmount.ToString(), currency = "USD", details = amountDetails};

	        var transaction = new Transaction {amount = amount, description = "For purchase of credits at RentIt"};

	        var transactions = new List<Transaction> {transaction};

	        var fundingInstrument = new FundingInstrument {credit_card = creditCard};

	        var fundingInstruments = new List<FundingInstrument> {fundingInstrument};

	        var payer = new Payer {funding_instruments = fundingInstruments, payment_method = "credit_card"};

	        var payment = new Payment {intent = "sale", payer = payer, transactions = transactions};
	        return payment;
	    }

	    private static string[] GetName(LoginInfo userLoginInfo)
		{
			var name = RentItDatabase.GetUserFirstAndLastName(userLoginInfo.UserId);
			var splitName = name.Split(' ');
			return splitName;
		}

		private static string GetOAuthToken()
		{
			var tokenCredential = new OAuthTokenCredential("AaxGuRCIKZ1wak76FBDayXQxi1zFo3PcNkdmnjPojsDCcvXfyQj5WZ07J_tg",
			                                               "EOzctBCAd8w4z66oCHHmYxKHP9tVUctl38DN5BjY6bxYrM_iDGhYnaW6T3Pc");
			var token = tokenCredential.GetAccessToken();
			return token;
		}

		public static List<FinancialTransaction> GetTransactionHistory(LoginInfo userInfo)
		{
			return RentItDatabase.GetTransactionHistory(userInfo.UserId);
		} 
	}
}
