﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Persistence;
using UserManagement;

namespace Finance
{
	public class ShoppingManager
    {
		/// <summary>
		/// Add item to shopping cart for future rental payment. If the video is already in the users shopping cart, will do nothing.
		/// If the item is already in the shopping cart, but marked for purchase, it will be marked for rental
		/// </summary>
        public static ShoppingCart AddRentalToShoppingCart(LoginInfo userInfo, int videoId)
        {
	        if (RentItDatabase.ItemInCart(userInfo.UserId, videoId))
	        {
				var info = RentItDatabase.GetCartItem(userInfo.UserId, videoId);
				if (info.PaymentType == "rent") return new ShoppingCart(userInfo.UserId);
				RemoveFromShoppingCart(userInfo, videoId);
	        }
	        RentItDatabase.AddRentalToShoppingCart(userInfo.UserId, videoId);
		    return new ShoppingCart(userInfo.UserId);
        }

		/// <summary>
		/// Add item to shopping cart for future purchase payment. If the video is already in the users shopping cart, will do nothing.
		/// If the item is already in the shopping cart, but marked for rental, it will be marked for purchase
		/// </summary>
        public static ShoppingCart AddPurchaseToShoppingCart(LoginInfo userInfo, int videoId)
        {
			if (RentItDatabase.ItemInCart(userInfo.UserId, videoId))
			{
				var info = RentItDatabase.GetCartItem(userInfo.UserId, videoId);
			    if (info.PaymentType == "buy") return new ShoppingCart(userInfo.UserId);
				RemoveFromShoppingCart(userInfo, videoId);
			}
			RentItDatabase.AddPurchaseToShoppingCart(userInfo.UserId, videoId);
		    return new ShoppingCart(userInfo.UserId);
        }

		/// <summary>
		/// Remove video from shopping cart. If the video is not in the shopping cart does nothing
		/// </summary>
        public static void RemoveFromShoppingCart(LoginInfo userInfo, int videoId)
        {
			if (RentItDatabase.ItemInCart(userInfo.UserId, videoId))
            RentItDatabase.RemoveFromShoppingCart(userInfo.UserId, videoId);
        }

        public static void ClearShoppingCart(LoginInfo userInfo)
        {
            RentItDatabase.ClearShoppingCart(userInfo.UserId);
        }

		/// <summary>
		/// Pay for all videos in shopping basket, and add access to videos.
		/// </summary>
		/// /// <exception cref="InsufficientFundsException">The user does not have enough RentIt credits to pay for the items in the shopping cart.</exception>
        public static void CheckOut(LoginInfo userInfo)
        {
			if (RentItDatabase.CartIsEmpty(userInfo.UserId)) return;
            var cart = new ShoppingCart(userInfo.UserId);
            if (cart.Total > RentItDatabase.GetUserbalance(userInfo.UserId))
                throw new InsufficientFundsException("The user does not have enough RentIt credits to checkout");

	        
	        //Update user balance
	        RentItDatabase.AddToUserBalance(-cart.Total, userInfo.UserId);
			//update user access to videos and save transaction
	        foreach (var item in cart.Items)
	        {

		        if (item.PaymentType == "rent")
		        {
			        RentItDatabase.SaveTransaction(userInfo.UserId, item.Video.Price.RentPrice, DateTime.Now, item.Video.Id);
			        RentItDatabase.AddToRentHistory(userInfo.UserId, item.VideoId, DateTime.Now);
		        }
		        else
		        {
			        RentItDatabase.SaveTransaction(userInfo.UserId, item.Video.Price.BuyPrice, DateTime.Now, item.Video.Id);
			        RentItDatabase.AddToBuyHistory(userInfo.UserId, item.VideoId, DateTime.Now);
		        }
	        }
	        ClearShoppingCart(userInfo);
        }
    }
}
