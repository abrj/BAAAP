﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MyService
{
    public class testClient
    {
         
        static void Main(string[] args)
        {
            MyMethod wcf = new MyMethod();
            wcf.testFault("S");
            //wcf.Download("small.mp4");
        }
    
    }
}