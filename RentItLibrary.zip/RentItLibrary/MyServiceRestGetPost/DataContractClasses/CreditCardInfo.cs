﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace MyService.DataContractClasses
{
    [DataContract]
    public class CreditCardInfo
    {

        [DataMember]
        public int CardNumber { get; set; }

        [DataMember]
        public int ExpireMonth { get; set; }

        [DataMember]
        public int ExpireYear { get; set; }

        [DataMember]
        public int SecurityNumber { get; set; }

    }
}