﻿using System.Runtime.Serialization;

namespace MyService.DataContractClasses
{
    [DataContract]
    public class VideoInfo
    {
        [DataMember]
        public int VideoId { get; set; }

        [DataMember]
        public string VideoTitle { get; set; }

        [DataMember]
        public string VideoType { get; set; }

        [DataMember]
        public string Description { get; set; }

        [DataMember]
        public double Length { get; set; }

        [DataMember]
        public string Category { get; set; }

        [DataMember]
        public string PriceCategory { get; set; }
        [DataMember]
        public string PathToThumbNail { get; set; }

        [DataMember]
        public double? AccumulatedRating { get; set; }

        [DataMember]
        public bool ForPuchase { get; set; }
}
}