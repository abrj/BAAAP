﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Web;

namespace MyService.DataContractClasses
{
    
    [DataContract(Name = "VideoUpload", Namespace = "http://rentit.itu.dk/rentit30/myService.svc")]
    public class VideoUpload
    {
        [DataMember]
        public string Token { get; set; }

        [DataMember]
        public FileStream Video { get; set; }

        [DataMember]
        public VideoInfo VideoInfo { get; set; }

        [DataMember]
        public FileStream Thumbnail { get; set; }

        [DataMember]
        public string ThumbnailType { get; set; }
    }
}