﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;
using System.ServiceModel;
namespace MyService.DataContractClasses
{
    [DataContract]
    public class ShoppingCart
    {
        [DataMember]
        public int UserId { get; set; }

        [DataMember]
        public double Total { get; set; }

        [DataMember]
        public readonly List<VideoInfo> Items = new List<VideoInfo>();
    }
}