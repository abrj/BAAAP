﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.ServiceModel.Web;
using System.Net;
using Finance;
using MyService.Models;
using MyService.DataContractClasses;
using Persistence;
using UserManagement;
using VideoManagement;
using Authorization = UserManagement.Authorization;
using ShoppingCart = MyService.DataContractClasses.ShoppingCart;
using System.Data.Entity.Validation;
using System.Diagnostics;


namespace MyService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "MyMethod" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select MyMethod.svc or MyMethod.svc.cs at the Solution Explorer and start debugging.
    public class MyMethod : IMyService
    {
        
		private void ThrowRestFaultException(HttpStatusCode status, String description)
		{
			var fault = new RestFaultException
			{
				HttpStatusCode = status,
				description = description
			};
			throw new WebFaultException<RestFaultException>(fault, fault.HttpStatusCode);
		}
         
        #region IMyMethod Members

        /// <summary>
        /// This method allows the user to login with Facebook
        /// </summary>
        /// The token representing the unique user id
        /// <param name="token"></param>
        /// <param name="rentItClientId"></param>
        public void LoginWithFacebook(string token, int rentItClientId)
        {
	        try
	        {
		        Authentication.Authenticate(token, rentItClientId);
		        if (WebOperationContext.Current != null)
			        WebOperationContext.Current.OutgoingResponse.StatusCode = HttpStatusCode.Accepted;
	        }
	        catch (InvalidTokenException)
	        {
				ThrowRestFaultException(HttpStatusCode.BadRequest, "The supplied token could not be used to authenticate the user." +
				                                                   "Either the token was malformed, exprired, or the app that issued the token is" +
				                                                   "not trusted by RentIt");
	        }
        }

        /// <summary>
        /// This method checks to see if a user is administrator or not.
        /// </summary>
        /// <param name="token"></param>
        /// <returns>a boolean value representing wheter or not a user is admin or not</returns>
        public bool IsAdministrator(string token)
        {
            LoginInfo login = Authentication.Validate((token));
            return Authorization.IsAdministrator(login);
        }


        /// <summary>
        /// This method ensures that the user is logged out correctly
        /// </summary>
        /// The token representing the unique user id
        /// <param name="token"></param>
        public void Logout(string token)
        {
	        Authentication.LogOut(token);
	        if (WebOperationContext.Current != null)
		        WebOperationContext.Current.OutgoingResponse.StatusCode = HttpStatusCode.Accepted;
        }

	    /// <summary>
        /// This method allows the user, if authenticated, to stream a specific video
        /// </summary>
        /// The token representing the unique user id
        /// <param name="token"></param>
        /// <param name="videoId"></param>
        /// Returns the videostream of the specific video
        /// <returns></returns>
        public Stream StreamVideo(string token, int videoId)
        {
            try
            {
	            var info = Authentication.Validate(token);    //Should be uncommented when not testing
                //var info = new LoginInfo(1,DateTime.Now, LoginInfo.Role.Administrator);  //created for testing purposes
	            return VideoManager.CreateStream(info, videoId);
            }
            catch (UserNotLoggedInException)
            {
	            ThrowRestFaultException(HttpStatusCode.Unauthorized, "You are not logged in");
            }
            catch (RentPeriodExceededException)
            {
	            ThrowRestFaultException(HttpStatusCode.PaymentRequired, "The rent period has expired");
            }
            catch (NoRentalInformationFoundException)
            {
	            ThrowRestFaultException(HttpStatusCode.PaymentRequired, "You need to pay for this video, in order to stream it");
            }
	        return null;

        }

        /// <summary>
        /// This method allows the user, if authenticated, to download a specific video
        /// </summary>
        /// The token representing the unique user id
        /// <param name="token"></param>
        /// The unique id for the specific video
        /// <param name="videoId"></param>
        /// Returns the file of the specific video
        /// <returns></returns>
        public string DownloadVideo(string token, int videoId)
        {
            try
            {
                LoginInfo loginInfo = Authentication.Validate(token);
                //var loginInfo = new LoginInfo(10, new DateTime(1999, 01, 01), new LoginInfo.Role());
           string videolink = VideoManager.CreateDownloadLink(loginInfo, videoId);
                if (WebOperationContext.Current != null)
                    WebOperationContext.Current.OutgoingResponse.StatusCode = HttpStatusCode.Accepted;
            return videolink;
        }
            catch (UserNotLoggedInException)
            {
                ThrowRestFaultException(HttpStatusCode.Unauthorized, "You are not logged in");
            }
            catch (NoPurchaseInformationFoundException)
            {
                ThrowRestFaultException(HttpStatusCode.PaymentRequired, "No purchase information for this user has been found");
            }

            return null;
           
        }

        public void UploadVideo(VideoUpload uploadVideo)
        {
           
            try
            {
                //Checks if the user is logged in
                LoginInfo loginInfo = Authentication.Validate(uploadVideo.Token);

                //Tryes to save the video
                VideoManager.SaveVideo(uploadVideo.VideoInfo.VideoTitle, uploadVideo.VideoInfo.Description,
                                       uploadVideo.VideoInfo.Length, uploadVideo.VideoInfo.Category,
                                       uploadVideo.VideoInfo.PriceCategory, uploadVideo.VideoInfo.VideoType,
                                       uploadVideo.Video, uploadVideo.Thumbnail, uploadVideo.ThumbnailType);
                if (WebOperationContext.Current != null)
                    WebOperationContext.Current.OutgoingResponse.StatusCode = HttpStatusCode.Accepted;
            }

          
                
            catch (Exception e)
            {
                RentItDatabase.SaveException(e);
                ThrowRestFaultException(HttpStatusCode.InternalServerError, "Something went wrong...");
            }
            
            
        }

        /// <summary>
        /// This method allows the user to rate a specific video
        /// </summary>
        /// The unique id of the specific video
        /// <param name="rating"></param>
        /// <param name="videoId"></param>
        /// <param name="token"></param>
        public void RateVideo(string token, int rating, int videoId)
        {
	        try
	        {
				var info = Authentication.Validate(token);
				VideoManager.RateVideo(info, videoId, rating);
		        if (WebOperationContext.Current != null)
			        WebOperationContext.Current.OutgoingResponse.StatusCode = HttpStatusCode.Accepted;
	        }
	        catch (UserNotLoggedInException)
	        {

		        ThrowRestFaultException(HttpStatusCode.Unauthorized, "You are not logged in");
	        }
        }

        /// <summary>
        /// This method gets the newest videos.
        /// </summary>
        /// Returns a list containing info for the newest videos
        /// <returns></returns>
        public List<VideoInfo> GetNewVideos()
        {
	        var videos = VideoManager.GetNewVideos();
	        return videos.Select(video => new VideoInfo
		        {
			        VideoId = video.Id, VideoTitle = video.Title, 
					AccumulatedRating = video.AverageRating, 
					Description = video.Description, 
					ForPuchase = false, 
					PathToThumbNail = video.ThumbPath, 
					VideoType = video.FileType
		        }).ToList();
        }

	    public List<VideoInfo> GetBuyHistory(string token)
	    {
		    var info = Authentication.Validate(token);
		    var videos = VideoManager.GetBuyHistory(info.UserId);
		    return videos.Select(video => new VideoInfo
			    {
				    AccumulatedRating = video.AverageRating,
					Category = video.Category,
					Description = video.Description, 
					ForPuchase = true, Length = video.Length, 
					PathToThumbNail = video.ThumbPath, 
					PriceCategory = video.PriceCategory, 
					VideoId = video.Id, 
					VideoTitle = video.Title, 
					VideoType = video.FileType
			    }).ToList();
	    }



	    public List<VideoInfo> GetRentHistory(string token)
	    {
			var info = Authentication.Validate(token);
		    var videos = VideoManager.GetActiveRentHistory(info.UserId);
           
			return videos.Select(video => new VideoInfo
			{
				AccumulatedRating = video.AverageRating,
				Category = video.Category,
				Description = video.Description,
				ForPuchase = true,
				Length = video.Length,
				PathToThumbNail = video.ThumbPath,
				PriceCategory = video.PriceCategory,
				VideoId = video.Id,
				VideoTitle = video.Title,
				VideoType = video.FileType
			}).ToList();
	    }

	    /// <summary>
        /// This method gets all available videos
        /// </summary>
        /// Returns a list containing info on all available videos
        /// <returns></returns>
        public List<VideoInfo> GetAllVideos()
        {
            
            var videos = VideoManager.GetAllVideos();
            return videos.Select(video => new VideoInfo
                {
			        VideoId = video.Id,
			        VideoTitle = video.Title,
			        AccumulatedRating = video.AverageRating,
			        Description = video.Description,
			        ForPuchase = false,
			        PathToThumbNail = video.ThumbPath,
			        VideoType = video.FileType
		        }).ToList();
        }

        /// <summary>
        /// This method gets all recommended videos
        /// </summary>
        /// Returns a list containing info on recommended videos
        /// <returns></returns>
        public List<VideoInfo> GetRecommendedVideos()
        {
			//TODO: add proper impl for recommended videos
	        return GetHighestRatedVideos();
        }

        /// <summary>
        /// This method gets the highest rated videos
        /// </summary>
        /// Returns a list containing info on the highest rated videos
        /// <returns></returns>
        public List<VideoInfo> GetHighestRatedVideos()
        {
			var videos = VideoManager.GetHighestRatedVideos();
			return videos.Select(video => new VideoInfo
			{
				VideoId = video.Id,
				VideoTitle = video.Title,
				AccumulatedRating = video.AverageRating,
				Description = video.Description,
				ForPuchase = false,
				PathToThumbNail = video.ThumbPath,
				VideoType = video.FileType
			}).ToList();
        }

        /// <summary>
        /// This method adds an element for rent to the shopping cart and returns the updated shopping cart
        /// </summary>
        /// The token representing the unique user id
        /// <param name="token"></param>
        /// The id of the user (should be changed to: The unique id of the video)?????s
        /// <param name="videoId"></param>
        /// <returns></returns>
        public ShoppingCart AddRentalToShoppingCart(string token, int videoId)
        {
            try
            {
                var info = Authentication.Validate(token);
                var sc = ShoppingManager.AddRentalToShoppingCart(info, videoId);
                var cart = new ShoppingCart {Total = sc.Total, UserId = info.UserId};
	            foreach (var vi in sc.Items.Select(item => new VideoInfo
                {
			            AccumulatedRating = item.Video.AverageRating,
			            VideoId = item.VideoId,
			            VideoTitle = item.Video.Title,
			            VideoType = item.Video.FileType,
			            Description = item.Video.Description,
			            PathToThumbNail = item.Video.ThumbPath
		            }))
	            {
                    cart.Items.Add(vi);
                }
                return cart;
            }
            catch (UserNotLoggedInException)
            {
                ThrowRestFaultException(HttpStatusCode.Unauthorized, "You are not logged in");
            }
	        return null;
        }

        /// <summary>
        /// This method adds an element for purchase to the shopping cart and returns the updated shopping cart
        /// </summary>
        /// The token representing the unique user id
        /// <param name="token"></param>
        /// <param name="videoId"></param>
        /// Returns the updated shopping cart
        /// <returns></returns>
        public ShoppingCart AddPurchaseToShoppingCart(string token, int videoId)
        {
            try
            {
                var info = Authentication.Validate(token);
                var sc = ShoppingManager.AddPurchaseToShoppingCart(info, videoId);
                var cart = new ShoppingCart {Total = sc.Total, UserId = info.UserId};
	            foreach (var vi in sc.Items.Select(item => new VideoInfo
		            {
			            AccumulatedRating = item.Video.AverageRating,
			            VideoId = item.VideoId,
			            VideoTitle = item.Video.Title,
			            VideoType = item.Video.FileType,
			            Description = item.Video.Description,
			            PathToThumbNail = item.Video.ThumbPath
		            }))
	            {
		            cart.Items.Add(vi);
	            }
                return cart;
            }
            catch (UserNotLoggedInException)
            {
                ThrowRestFaultException(HttpStatusCode.Unauthorized, "You are not logged in");
            }
	        return null;
        }

	    public ShoppingCart GetShoppingCart(string token)
	    {
		    var info = Authentication.Validate(token);
		    var sc = new Persistence.ShoppingCart(info.UserId);
		    var dcsc = new ShoppingCart();
		    foreach (var vi in sc.Items.Select(item => new VideoInfo
			    {
				    AccumulatedRating = item.Video.AverageRating,
				    Description = item.Video.Description,
				    ForPuchase = item.PaymentType == "buy",
				    PathToThumbNail = item.Video.ThumbPath,
				    VideoId = item.Video.Id,
				    VideoTitle = item.Video.Title,
				    VideoType = item.Video.FileType
			    }))
		    {
			    dcsc.Items.Add(vi);
		    }
		    dcsc.UserId = info.UserId;
		    dcsc.Total = sc.Total;
		    return dcsc;
	    }

	    /// <summary>
        /// This method checks out the shopping cart in order for the user to pay for the containing items
        /// </summary>
        /// The token representing the unique user id
        /// <param name="token"></param>
        public void CheckoutShoppingCart(string token)
        {
	        try
	        {
		        var info = Authentication.Validate(token);
		        ShoppingManager.CheckOut(info);
		        if (WebOperationContext.Current != null)
		        WebOperationContext.Current.OutgoingResponse.StatusCode = HttpStatusCode.Accepted;
	        }
	        catch (UserNotLoggedInException)
	        {
		        ThrowRestFaultException(HttpStatusCode.Unauthorized, "You are not logged in");
	        }
	        catch (InsufficientFundsException)
	        {
		        ThrowRestFaultException(HttpStatusCode.PaymentRequired, "You do not have enough RentIt credits to pay for the items in the shoppingcart");
	        }
        }

        /// <summary>
        /// This method removes an element from the shopping cart
        /// </summary>
        /// The token representing the unique user id
        /// <param name="token"></param>
        /// <param name="videoId"></param>
        public void RemoveVideoFromShoppingCart(string token, int videoId)
        {
            try
            {
                LoginInfo info = Authentication.Validate(token);
                ShoppingManager.RemoveFromShoppingCart(info, videoId);
            }
            catch (UserNotLoggedInException)
            {
                ThrowRestFaultException(HttpStatusCode.Unauthorized, "You are not logged in");
            }
        }

        /// <summary>
        /// This method removes all items from the shopping cart
        /// </summary>
        /// The token representing the unique user id
        /// <param name="token"></param>
        public void ClearShoppingCart(string token)
        {
	        try
	        {
				var info = Authentication.Validate(token);
				ShoppingManager.ClearShoppingCart(info);
		        if (WebOperationContext.Current != null)
				WebOperationContext.Current.OutgoingResponse.StatusCode = HttpStatusCode.Accepted;
	        }
	        catch (UserNotLoggedInException)
	        {
		        ThrowRestFaultException(HttpStatusCode.Unauthorized, "You are not logged in");
	        }
        }

        /// <summary>
        /// This method allows the user to deposit credits to his or hers personal account
        /// </summary>
        /// The token representing the unique user id
        /// <param name="token"></param>
        /// <param name="amount"></param>
        /// <param name="cardNumber"></param>
        /// <param name="expireMonth"></param>
        /// <param name="expireYear"></param>
        /// <param name="securityNumber"></param>
        /// <param name="cardType"></param>
        public void DepositCredits(string token, int amount, string cardNumber, int expireMonth, int expireYear, int securityNumber, string cardType)
        {
	        try
	        {
		        var info = Authentication.Validate(token);
		        AccountManager.Deposit(amount, info, cardNumber, expireMonth, expireYear, securityNumber, cardType);
		        if (WebOperationContext.Current != null)
		        WebOperationContext.Current.OutgoingResponse.StatusCode = HttpStatusCode.Accepted;
	        }
	        catch (UserNotLoggedInException)
	        {
		        ThrowRestFaultException(HttpStatusCode.Unauthorized, "You are not logged in");
	        }
	        catch (CreditCardCredentialsException)
	        {
		        ThrowRestFaultException(HttpStatusCode.BadRequest, "The supplied credit card credentials were denied");
	        }
        }

        /// <summary>
        /// This method converts the users credits (Both ways????)
        /// </summary>
        /// The token representing the unique user id
        /// Returns the converted amount of credits
        /// <returns></returns>
        public float ConvertCredits(int amount, string currency)
        {
            return AccountManager.ConvertCurrencyToRentItCredits(amount, currency);
        }

        /// <summary>
        /// This methos gets the transaction history for the specific user
        /// </summary>
        /// The token representing the unique user id
        /// <param name="token"></param>
        /// Returns a list containing the users transactions
        /// <returns></returns>
        public List<Transaction> GetTransactionHistory(string token)
        {
	        try
	        {
				var info = Authentication.Validate(token);
				var transactions = AccountManager.GetTransactionHistory(info);
		        var trans = new List<Transaction>();
		        foreach (var financialTransaction in transactions)
		        {
			        var t = new Transaction
				        {
					        TransactionDate = financialTransaction.TransactionTimeStamp,
					        Amount = financialTransaction.Amount
				        };
			        try
			        {
				        t.ForPurchaseOfVideo = financialTransaction.Video.Title;
			        }
			        catch (NullReferenceException)
			        {
						
				        t.ForPurchaseOfVideo = "";
			        }
		        }
		        return trans;
	        }
	        catch (UserNotLoggedInException)
	        {
		        ThrowRestFaultException(HttpStatusCode.Unauthorized, "You are not logged in");
	        }
	        return null;
        }

		/// <summary>
		/// This method lets an admin get information about a single user
		/// </summary>
		public UserInfo GetUser(string token)
		{
			try
			{
				var info = Authentication.Validate(token);
				var user = UserManager.GetUser(info);
				return new UserInfo
					{
						Id = user.Id,
						Name = user.Name,
						Birthday = user.Birthday,
						City = user.City,
						Email = user.EmailAddress,
						Sex = user.Sex,
						Balance = user.Balance

					};
			}
			catch (UserNotLoggedInException)
			{
				ThrowRestFaultException(HttpStatusCode.Unauthorized, "You are not logged in");
			}
			return null;
		}
        
        /// <summary>
        /// This method lets an admin get information about a single user
        /// </summary>
        /// <param name="token">The admins token</param>
        /// <param name="userId">The id of the returned user</param>
        /// <returns></returns>
        public UserInfo GetOtherUser(string token, int userId)
        {
			try
			{
				var info = Authentication.Validate(token);
				if (!Authorization.IsAdministrator(info)) ThrowRestFaultException(HttpStatusCode.Unauthorized, "Only administrators can access this method");
				var user = UserManager.GetUser(userId);
				return new UserInfo
				{
					Id = user.Id,
					Name = user.Name,
					Birthday = user.Birthday,
					City = user.City,
					Email = user.EmailAddress,
					Sex = user.Sex,
					Role = user.Role
				};
			}
			catch (UserNotLoggedInException)
			{
				ThrowRestFaultException(HttpStatusCode.Unauthorized, "You are not logged in");
			}
			return null;
        }

        /// <summary>
        /// This method gets info on all users on the system
        /// </summary>
        /// The token representing the unique user id
        /// <param name="token"></param>
        /// Returns a list containing info on all users
        /// <returns></returns>
        public List<UserInfo> GetAllUsers(string token)
        {
	        try
	        {
				var info = Authentication.Validate(token);
				if (!Authorization.IsAdministrator(info)) ThrowRestFaultException(HttpStatusCode.Unauthorized, "Only administrators can access this method");
				return UserManager.GetAllUsers().Select(u => new UserInfo
					{
						Id = u.Id,
						Name = u.Name,
						Birthday = u.Birthday,
						City = u.City,
						Email = u.EmailAddress,
						Role = u.Role,
						Sex = u.Sex
					}).ToList();
	        }
	        catch (UserNotLoggedInException)
	        {
				ThrowRestFaultException(HttpStatusCode.Unauthorized, "You are not logged in");
	        }
	        return null;
        }

        /// <summary>
        /// This method deletes the specified user
        /// </summary>
        /// <param name="token"></param>
        /// <param name="userId"></param>
        public void DeleteUser(string token, int userId)
        {
	        try
	        {
				var info = Authentication.Validate(token);
				if (!Authorization.IsAdministrator(info)) ThrowRestFaultException(HttpStatusCode.Unauthorized, "Only administrators can access this method");
				UserManager.DeleteUser(userId);
	        }
	        catch (UserNotLoggedInException)
	        {
				ThrowRestFaultException(HttpStatusCode.Unauthorized, "You are not logged in");
	        }
        }

        /// <summary>
        /// This method deletes a specific video
        /// </summary>
        /// The token representing the unique user id
        /// <param name="token"></param>
        /// <param name="videoId"></param>
        public void DeleteVideo(string token, int videoId)
        {
	        try
	        {
				var info = Authentication.Validate(token);
				if (!Authorization.IsAdministrator(info)) ThrowRestFaultException(HttpStatusCode.Unauthorized, "Only administrators can access this method");
				VideoManager.DeleteVideo(videoId);
	        }
	        catch (UserNotLoggedInException)
	        {
				ThrowRestFaultException(HttpStatusCode.Unauthorized, "You are not logged in");
	        }
        }


        public List<VideoInfo> GetVideoByKeyWord(string keyword)
        {
            var videos = VideoManager.GetVideosByKeyWord(keyword);
            return videos.Select(video => new VideoInfo
            {
                VideoId = video.Id,
                VideoTitle = video.Title,
                AccumulatedRating = video.AverageRating,
                Description = video.Description,
                ForPuchase = false,
                PathToThumbNail = video.ThumbPath,
                VideoType = video.FileType
            }).ToList();
        }



        /* public bool Upload(UploadStream data) 
        {
            
            //FileStream fileStream = data as FileStream;  //Casting to FileStream to retrieve the name of the file
            //String path = data.Name;
            string fileName = data.fileName;
            Stream fileStream = data.fileStream;
            String path = @"C:\RentItServices\Rentit30\" + fileName;
            try
            {
                using (Stream file = File.OpenWrite(path))
                {
                    CopyStream(fileStream, file);

                }
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
             
            return true;
        }
    */
        

        #endregion
	}
}
