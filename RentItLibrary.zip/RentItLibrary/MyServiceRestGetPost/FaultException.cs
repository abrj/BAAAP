﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Runtime.Serialization;
using System.IO;

namespace MyService
{
    [DataContract]
    public class FaultException
    {
        public FaultException(string reason)
        {
            Reason = reason;
        }

        [DataMember]
        public string Reason { get; private set; }
    }
}