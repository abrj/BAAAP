﻿using System.Collections.Generic;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.IO;
using MyService.Models;
using MyService.DataContractClasses;
using System.ComponentModel;

namespace MyService
{
	// NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IMyMethod" in both code and config file together.
	//Service interface
    [ServiceContract]
	public interface IMyService
	{
		[OperationContract]
        [Description("This method allows the user to login with Facebook")]
		[WebInvoke(Method = "GET", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest,
			UriTemplate = "LoginWithFacebook/?token={token}&rentItClientId={rentItClientId}")]
        void LoginWithFacebook(string token, int rentItClientId);


        [OperationContract]
        [Description("This method checks to see if the user is administrator")]
        [WebInvoke(Method = "GET", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest,
            UriTemplate = "IsAdministrator/?token={token}")]
        bool IsAdministrator(string token);


        [OperationContract]
        [Description("This method ensures that the user is logged out correctly")]
		[WebInvoke(Method = "UPDATE", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest,
			UriTemplate = "Logout/?token={token}")]
        void Logout(string token);

        [OperationContract]
		[Description("This method ensures that the user is logged out correctly")]
		[WebInvoke(Method = "UPDATE", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest,
			UriTemplate = "GetUser/?token={token}")]
		UserInfo GetUser(string token);

		[OperationContract]
        [Description("This method allows the user, if authenticated, to stream a specific video")]
		[WebInvoke(Method = "GET", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest,
			UriTemplate = "StreamVideo/?token={token}&videoId={videoId}")]
        Stream StreamVideo(string token, int videoId);

        [OperationContract]
        [Description("This method allows the user, if authenticated, to download a specific video")]
        [WebInvoke(Method = "GET", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest, UriTemplate = "DownloadVideo/?token={token}&videoId={videoId}")]
        string DownloadVideo(string token, int videoId);

        [OperationContract]
        [Description("This method allows the user to upload")]
        [WebInvoke(Method = "POST", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest, UriTemplate = "UploadVideo/?VideoUpload=videoUpload")]
        void UploadVideo(VideoUpload video);

        [OperationContract]
        [Description("This method allows the user to rate a specific video")]
		[WebInvoke(Method = "POST", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest,
			UriTemplate = "RateVideo/?token={token}&rating={rating}&videoId={videoId}")]
        void RateVideo(string token, int rating, int videoId);

        [OperationContract]
        [Description("This method gets the newest videos")]
		[WebInvoke(Method = "GET", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest,
			UriTemplate = "GetNewVideos/?")]
        List<VideoInfo> GetNewVideos();

        [OperationContract]
		[Description("This method gets purchases for a user")]
		[WebInvoke(Method = "GET", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest,
			UriTemplate = "GetBuyHistory/?token={token}")]
		List<VideoInfo> GetBuyHistory(string token);

		[OperationContract]
		[Description("This method gets rents for a user")]
		[WebInvoke(Method = "GET", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest,
			UriTemplate = "GetRentHistory/?token={token}")]
		List<VideoInfo> GetRentHistory(string token);

        [OperationContract]
        [Description("This method allows the user to retrieve all available videos")]
		[WebInvoke(Method = "GET", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest,
			UriTemplate = "GetAllVideos/?")]
        List<VideoInfo> GetAllVideos();

        [OperationContract]
        [Description("This method allows the user to retrieve recommended videos")]
		[WebInvoke(Method = "GET", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest,
			UriTemplate = "GetRecommendedVideos/?")]
        List<VideoInfo> GetRecommendedVideos();

        [OperationContract]
        [Description("This method allows the user to retrieve the highest rated videos")]
		[WebInvoke(Method = "GET", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest,
			UriTemplate = "GetHighestRatedVideos/?")]
        List<VideoInfo> GetHighestRatedVideos();

        [OperationContract]
		[Description(
			"This method adds an element for rent to the shopping cart and returns the updated shopping cart to the user")]
		[WebInvoke(Method = "POST", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest,
			UriTemplate = "AddRentalToShoppingCart/?token={token}&videoId={videoId}")]
        ShoppingCart AddRentalToShoppingCart(string token, int videoId);

        [OperationContract]
		[Description(
			"This method adds an element for purchase to the shopping cart and returns the updated shopping cart to the user")]
		[WebInvoke(Method = "POST", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest,
			UriTemplate = "AddPurchaseToShoppingCart/?token={token}&video={videoId}")]
        ShoppingCart AddPurchaseToShoppingCart(string token, int videoId);

		[OperationContract]
		[Description(
			"Gets the shopping cart for the user")]
		[WebInvoke(Method = "GET", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest,
			UriTemplate = "GetShoppingcart/?token={token}")]
		ShoppingCart GetShoppingCart(string token);

        [OperationContract]
        [Description("This method checks out the shopping cart in order to pay for the items")]
		[WebInvoke(Method = "UPDATE", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest,
			UriTemplate = "CheckoutShoppingCart/?token={token}")]
        void CheckoutShoppingCart(string token);

        [OperationContract]
        [Description("This method removes a video from the shopping cart")]
		[WebInvoke(Method = "DELETE", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest,
			UriTemplate = "RemoveVideoFromShoppingCart/?token={token}&videoId={videoId}")]
        void RemoveVideoFromShoppingCart(string token, int videoId);

        [OperationContract]
        [Description("This method removes all items from the shopping cart")]
		[WebInvoke(Method = "UPDATE", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest,
			UriTemplate = "ClearShoppingCart/?token={token}")]
        void ClearShoppingCart(string token);

        [OperationContract]
        [Description("This method enables the user to deposit credits to his account")]
		[WebInvoke(Method = "GET", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest,
			UriTemplate =
                "DepositCredits/?token={token}&amount={amount}&cardNumber={cardNumber}&expireMonth={expireMonth}&expireYear={expireYear}&securityNumber={securityNumber}&cardType={cardType}"
			)]
		void DepositCredits(string token, int amount, string cardNumber, int expireMonth, int expireYear, int securityNumber,
		                    string cardType);

        [OperationContract]
        [Description("This method converts the users credits to rentit money")]
		[WebInvoke(Method = "POST", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest,
			UriTemplate = "ConvertCredits/?amount={amount}&currency={currency}")]
        float ConvertCredits(int amount, string currency);

        [OperationContract]
        [Description("This method get the transaction history for the specific user")]
		[WebInvoke(Method = "GET", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest,
			UriTemplate = "GetTransactionHistory/?token={token}")]
        List<Transaction> GetTransactionHistory(string token);

        [OperationContract]
        [Description("This method gets info on a specific user from the system")]
        [WebInvoke(Method = "GET", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest, UriTemplate = "GetOtherUser/?token={token}&userId={userId}")]
        UserInfo GetOtherUser(string token, int userId);
        
        [OperationContract]
        [Description("This method gets info on all users on system")]
		[WebInvoke(Method = "GET", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest,
			UriTemplate = "GetAllUsers/?token={token}")]
        List<UserInfo> GetAllUsers(string token);

        [OperationContract]
        [Description("This method deletes the specific user")]
		[WebInvoke(Method = "DELETE", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest,
			UriTemplate = "DeleteUser/?token={token}&userId={userId}")]
        void DeleteUser(string token, int userId);

        [OperationContract]
        [Description("This method deletes a specific video")]
		[WebInvoke(Method = "DELETE", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest,
			UriTemplate = "DeleteVideo/?token={token}&videoId={videoId}")]
        void DeleteVideo(string token, int videoId);

        [OperationContract]
        [Description("This method returns a video(s) by keyword")]
        [WebInvoke(Method = "GET", ResponseFormat = WebMessageFormat.Json,
            BodyStyle = WebMessageBodyStyle.WrappedRequest,
            UriTemplate = "GetVideoByKeyWord/?keyword={keyword}")]
        List<VideoInfo> GetVideoByKeyWord(string keyword);

	}
}
