﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcClient;
using MvcClient.RentItServices;

namespace MvcClient.Controllers
{
    [Authorize]
    public class HomeController : Controller
    {

        private MvcClient.RentItServices.MyServiceClient ris = new MvcClient.RentItServices.MyServiceClient();
        //
        // GET: /Home/
        
        public ActionResult Index()
        {
            RentItServices.VideoInfo[] videoInfos = ris.GetAllVideos();
            return View(videoInfos);
        }

        public ActionResult Newest()
        {
            RentItServices.VideoInfo[] videoInfos = ris.GetNewVideos();
            return View(videoInfos);
        }

    }
}
