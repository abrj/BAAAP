﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Persistence;

namespace PersistenceTest
{
	[TestClass]
	public class UserTests
	{
		[TestMethod]
		public void TestCreateAndDeleteUser()
		{
			const int id = 2;
			RentItDatabase.CreateUser(id, new DateTime(1987,7,23), "sdeb@itu.dk", "København V", "Sune Debel", "male");
			Assert.IsTrue(RentItDatabase.UserExists(id));
			RentItDatabase.DeleteUser(id);
			Assert.IsFalse(RentItDatabase.UserExists(id));
		}

		[TestMethod]
		public void TestUserExists()
		{
			Assert.IsTrue(RentItDatabase.UserExists(1206731771));
			Assert.IsFalse(RentItDatabase.UserExists(-1000));
		}

        [TestMethod]
        public void TestGetUser()
        {
            const int id = 2;
            RentItDatabase.CreateUser(id, new DateTime(1987, 7, 23), "sdeb@itu.dk", "København V", "Sune Debel", "male");
            Assert.AreEqual("Sune Debel", RentItDatabase.GetUser(id).Name);
            RentItDatabase.DeleteUser(id);
        }

		[TestMethod]
		public void TestUpdateUser()
		{
			const int id = 2;
			RentItDatabase.CreateUser(id, new DateTime(1987, 7, 23), "sdeb@itu.dk", "København V", "Sune Debel", "male");
			RentItDatabase.UpdateUser(id,"newEmail@mail.com", "newTown", "New Name", "female");
			RentItDatabase.DeleteUser(id);
		}

		[TestMethod]
		public void TestGetUserRole()
		{
			var actual = RentItDatabase.GetUserRole(1302406399);
			Assert.AreEqual("User", actual);
		}

        [TestMethod]
		public void TestGetUserFirstAndLastName()
        {
            var name = RentItDatabase.GetUserFirstAndLastName(1206731771);
            Assert.AreEqual("Sune Debel", name);
        }
	}
}
