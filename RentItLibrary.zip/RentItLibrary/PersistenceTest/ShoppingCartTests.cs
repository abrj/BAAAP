﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Persistence;

namespace PersistenceTest
{
	[TestClass]
	public class ShoppingCartTests
	{
		[TestMethod]
		public void TestItemInCart()
		{
			RentItDatabase.AddRentalToShoppingCart(1302406399, 10);
			Assert.IsTrue(RentItDatabase.ItemInCart(1302406399, 10));
			RentItDatabase.RemoveFromShoppingCart(1302406399, 10);
			Assert.IsFalse(RentItDatabase.ItemInCart(1302406399, 10));
		}
	}
}
