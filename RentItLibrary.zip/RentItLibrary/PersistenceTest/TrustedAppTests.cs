﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Persistence;

namespace PersistenceTest
{
	[TestClass]
	public class TrustedAppTests
	{
		[TestMethod]
		public void TestGetTrustedAppFacebookId()
		{
			var trustedappId = RentItDatabase.GetFacebookAppId(123456);
			Assert.AreEqual(145634995501895, trustedappId);
		}
	}
}
