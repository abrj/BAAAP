﻿using System;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Persistence;

namespace PersistenceTest
{
	[TestClass]
	public class RentalInformationTests
	{
		[TestMethod]
		public void TestGetRentalInformationNoneExists()
		{
			try
			{
				RentItDatabase.GetNewestRentalInformation(1, 1);
			}
			catch (InvalidOperationException)
			{
				//Success!
			}
		}

		[TestMethod]
		public void TestGetNewestRentalInformationReturnsNewest()
		{
			var newest = RentItDatabase.GetNewestRentalInformation(1206731771, 2);
			var otherInfos = RentItDatabase.GetRenthistory(1206731771).Where(ri => ri.VideoId == 2);
			foreach (var rentalInformation in otherInfos)
			{
				Assert.IsTrue(rentalInformation.RentDate <= newest.RentDate);
			}
		}
	}
}
