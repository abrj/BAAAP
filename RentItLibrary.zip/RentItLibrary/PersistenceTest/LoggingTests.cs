﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace PersistenceTest
{
	[TestClass]
	public class LoggingTests
	{
		[TestMethod]
		public void TestSaveException()
		{
			var e = new Exception("Test exception");
			Persistence.RentItDatabase.SaveException(e);

		}
	}
}
