﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Persistence;

namespace PersistenceTest
{
	[TestClass]
	public class VideoTests
	{
		[TestMethod]
		public void TestGetAllVideos()
		{
			var videos = RentItDatabase.GetAllVideos();
		}

        [TestMethod]
        public void TestNewestVideos()
        {
            var videos = RentItDatabase.GetNewVideos();
        }

		[TestMethod]
		public void TestSearchVideos()
		{
			var videos = RentItDatabase.SearchForVideo("Mario");
		}

		[TestMethod]
		public void TestGetRentHistory()
		{
			var videos = RentItDatabase.GetRentHistory(1302406399, new TimeSpan (24, 0, 0));
		}

		[TestMethod]
		public void TestGetBuyHistory()
		{
			var videos = RentItDatabase.GetBuyHistory(1302406399);
		}


		[TestMethod]
		public void TestGetAverageRating()
		{
			var videos = RentItDatabase.GetVideo(10);
			Console.Out.WriteLine(videos.AverageRating);
		}

		[TestMethod]
		public void TestHighestRatedVideos()
		{
			var videos = RentItDatabase.GetHighestRatedVideos();
			foreach (var video in videos)
			{
				Console.Out.WriteLine(video.AverageRating);
			}
		}

	    [TestMethod]
	    public void TestGetVideoPath()
	    {
	        var path = RentItDatabase.GetPermanentPathToVideo(10);

	    }

        [TestMethod]
        public void TestGetVideo()
        {
            var video = RentItDatabase.GetVideo(10);

        }

	}
}
