﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Persistence;

namespace PersistenceTest
{
	[TestClass]
	public class RatingsTests
	{
		[TestMethod]
		public void TestSaveAndDeleteRating()
		{
			RentItDatabase.SaveRating(5, 25, 1206731771);
			RentItDatabase.DeleteRating(25, 1206731771);
		}
	}
}
