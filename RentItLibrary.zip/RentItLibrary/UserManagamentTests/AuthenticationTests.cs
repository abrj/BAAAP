﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using UserManagement;

namespace UserManagementTests
{
	[TestClass]
	public class AuthenticationTests
	{
		//TODO: Get token from facebook
		private const string Token = "AAACEdEose0cBAJBW9QC3KdtoLZCFi4uCIhLr5zxZBDuKHMU1wpZCGnZBnHuq1ZBJHeAldZBsB19mVieHGuewWb2EzGfIF9iyZCRcwytKJ9WNlaKdwyTvBzh";

		[TestMethod]
		public void TestAuthenticateAndValidate()
		{
			Authentication.Authenticate(Token, 123456);
			var info = Authentication.Validate(Token);
			Assert.AreEqual(info.UserId, 1206731771);
			Assert.AreEqual(info.UserRole, LoginInfo.Role.Administrator);
		}

		[TestMethod]
		public void TestAuthenticateTwice()
		{
			Authentication.Authenticate(Token, 123456);

			Authentication.Authenticate(Token, 123456);
			
		}

		[TestMethod]
		public void TestLogOut()
		{
			Authentication.Authenticate(Token, 123456);
			Authentication.LogOut(Token);
			try
			{
				Authentication.Validate(Token);
			}
			catch
			{
				//Success!
			}
		}

		[TestMethod]
		public void TestLogOutUserNotLoggedIn()
		{
			Authentication.LogOut(Token);
		}

		[TestMethod]
		public void TestValidateUserNotLoggedIn()
		{
			try
			{
				Authentication.Validate(Token);
			}
			catch
			{
				
				//Success!
			}
			
		}
	}
}
